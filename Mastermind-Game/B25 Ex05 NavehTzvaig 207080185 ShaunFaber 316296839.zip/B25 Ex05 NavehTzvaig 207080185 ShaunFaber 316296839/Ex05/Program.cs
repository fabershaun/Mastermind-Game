﻿namespace Ex05
{
    internal class Program
    {
        public static void Main()
        {
            UIManager uiManager = new UIManager();

            uiManager.Run();
        }
    }
}